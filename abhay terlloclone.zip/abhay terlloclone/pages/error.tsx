import React from 'react';

const Error = () => {
  return (
    <h1>
      Galti ho gyi
      <span role="img" aria-label="pray">
        🙏🏻
      </span>
    </h1>
  );
};

export default Error;
